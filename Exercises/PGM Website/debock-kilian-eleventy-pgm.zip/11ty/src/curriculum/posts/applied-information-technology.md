---
title: applied information technology
description: Je verdiept je in de geschiedenis en de werking van het internet en ontdekt de logica achter programmeren. Daarnaast duik je in de informatie rond hardware, software en netwerken. Later staan onder meer databases, security en blockchain op het programma.
---

# {{ title }}

{{ description }}