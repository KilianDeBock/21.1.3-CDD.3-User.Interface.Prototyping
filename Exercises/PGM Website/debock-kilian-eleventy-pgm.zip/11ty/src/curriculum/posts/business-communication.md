---
title: business & communication
description: Je ontdekt hoe bedrijven georganiseerd zijn, je leert handleidingen schrijven en je krijgt een dieper inzicht in marketing en bedrijfscommunicatie. Je leert pitchen voor klanten en samenwerken in team. In het laatste semester geven we je bovendien alle kennis mee die je nodig hebt om als zelfstandige IT’er aan de slag te gaan.
---

# {{ title }}

{{ description }}