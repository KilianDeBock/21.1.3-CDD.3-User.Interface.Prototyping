---
title: computer programming
description: Bereid je voor om een expert te worden in front-end web development. Je wordt expert in JavaScript en leert werken met React, Node.js, TypeScript, PHP en SQL. Om je optimaal klaar te stomen voor een job als programmeur, krijg je diverse gastcolleges van experten uit het werkveld en werk je aan authentieke cases.
---

# {{ title }}

{{ description }}