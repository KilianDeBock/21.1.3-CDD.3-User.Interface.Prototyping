---
title: ui/ux prototyping
description: In de vakken van deze programmalijn verdiep je je in de codeertalen HTML en CSS. Je leert werken met grafische software en gaat design thinking toepassen. Ook ga je aan de slag met CMS-systemen zoals WordPress.
---

# {{ title }}

{{ description }}