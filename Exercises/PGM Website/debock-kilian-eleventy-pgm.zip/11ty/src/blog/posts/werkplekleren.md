---
title: Werkplekleren
description: Studenten Silke, Nicolas en Ryan getuigen over hun eerste ervaringen in het werkveld. Veli trok er op uit om hun te interviewen.
---

# {{ title }}


## Silke aan het woord
Silke Van Meerbeek loopt stage bij maneuver een ontwerpbureau dat met grafische verfijning en interactieve media zin geeft aan merkverhalen. Silke werkt vooral met #vue, #wordpress en #nuxt. Succes Silke!


## Nicolas goes international
Nicolas Cnudde loopt stage bij SQLI Digital Experience Belgium een internationaal softwarebedrijf gespecialiseerd in het implementeren van #commerce applicaties voor internationale A-merken. “Programming is a skill best acquired by practice and example rather than from books.” Deze quote sluit volledig aan bij onze opleiding. Dankzij de praktijkgerichte approach krijgen studenten een zeer sterke basis aangeleerd in een relatief korte tijd. Nicolas werkt vooral met #drupal, #twig, #docker en #vue.


## Ryan werkt Laravel
Ryan Judd loopt stage bij MDware, een softwarebedrijf uit Gent gespecialiseerd in o.a. #lightspeed. Ryan werkt vooral met #laravel en #bootstrap. Succes Ryan!
