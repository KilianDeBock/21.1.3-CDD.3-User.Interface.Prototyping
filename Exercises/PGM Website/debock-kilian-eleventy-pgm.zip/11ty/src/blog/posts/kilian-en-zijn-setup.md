---
title: kilian en zijn setup
description: Kilian gebruikt in onze opleiding een eigen custom setup om zo goed mogelijk te programmeren.
---

# {{ title }}

{{ description }}