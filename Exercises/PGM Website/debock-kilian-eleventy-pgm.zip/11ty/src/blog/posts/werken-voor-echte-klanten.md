---
title: werken voor echte klanten
description: Onze 2de jaars studenten zijn voor het vak @work3 realistische applicaties aan het maken voor echte klanten.
---

# {{ title }}

{{ description }}